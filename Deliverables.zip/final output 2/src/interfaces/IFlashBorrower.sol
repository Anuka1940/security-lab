// SPDX-License-Identifier: MIT
pragma solidity =0.8.25;

interface IFlashBorrower {
    function onFlashLoan(address initiator, address token, uint256 amount, uint256 fee, bytes calldata data)
        external
        returns (bytes32);
}
